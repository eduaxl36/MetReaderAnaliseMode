#!/bin/sh
javac -classpath .:../../../lib/sshfactory.jar -d . TelnetExample.java
java -cp .:../../../lib/sshfactory.jar TelnetExample
