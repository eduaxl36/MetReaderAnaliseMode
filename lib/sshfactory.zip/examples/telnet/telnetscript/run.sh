#!/bin/sh
javac -classpath .:../../../lib/sshfactory.jar -d . TelnetScriptExample.java
java -cp .:../../../lib/sshfactory.jar TelnetScriptExample
