#!/bin/sh
java -jar ../../../lib/sshfactory.jar -f sshdirlistingfiltered.txt -filter '*.txt'
