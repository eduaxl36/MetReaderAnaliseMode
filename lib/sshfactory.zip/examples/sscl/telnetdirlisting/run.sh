#!/bin/sh
java -jar ../../../lib/sshfactory.jar -f telnetdirlisting.txt
